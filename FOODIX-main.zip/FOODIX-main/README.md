# FOODIX
FOODIX is a frontend application of Online food ordering system that customises your needs and provides you with options around you.
It also provides details on hygiene,Customer Reviews & provides you with cheap,affordable options.

![p1](https://github.com/maity563/FOODIX/assets/105879104/557de56d-bdbd-4bb6-8c2c-23d079cd01a8)
![p2](https://github.com/maity563/FOODIX/assets/105879104/b3d93a59-217a-4b6f-8db7-1e737338cb85)
![p3](https://github.com/maity563/FOODIX/assets/105879104/463f1471-885a-4089-a40b-b1ded729f233)
![p4](https://github.com/maity563/FOODIX/assets/105879104/d01a962d-3ec4-4a07-947c-6d7ab564fdc1)




